#ifndef __RF24_INCLUDES_H__
#define __RF24_INCLUDES_H__

#define RF24_PIGPIO

#include "pigpio/RF24_arch_config.h"
#ifndef RF24_NO_INTERRUPT
    #include "pigpio/interrupt.h"
#endif

#endif
